package com.example.fooddemoapp;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements RestaurantAdapter.OnRestaurantAdapterClickListener {

    // Recycler View
    private RecyclerView recyclerView;
    private RestaurantAdapter adapter;

    private List<Restaurant> restaurantList;

    private DatabaseReference databaseRestaurants;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseRestaurants = FirebaseDatabase.getInstance().getReference("restaurants");

        restaurantList = new ArrayList<>();

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Agregando el Listener para capturar los Clicks



    } // Fin de la Funcion onCreate

    @Override
    protected void onStart() {
        super.onStart();

        databaseRestaurants.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                restaurantList.clear(); // Ver la forma de no crear listas en cada momento

                for (DataSnapshot restSnapshot : dataSnapshot.getChildren()){
                    Restaurant rest = restSnapshot.getValue(Restaurant.class);

                    restaurantList.add(rest);
                }


                adapter = new RestaurantAdapter(MainActivity.this,restaurantList,MainActivity.this);
                recyclerView.setAdapter(adapter);


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    } // Fin de la funcion onStart



    @Override
    public void onRecyclerViewClick(int pos) {
        Toast.makeText(this, restaurantList.get(pos).getRestTitle() + " clicked!", Toast.LENGTH_SHORT).show();
    }
}

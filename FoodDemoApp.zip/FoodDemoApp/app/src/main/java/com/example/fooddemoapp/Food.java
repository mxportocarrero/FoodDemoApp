package com.example.fooddemoapp;

public class Food {
}

package com.example.fooddemoapp;

public class Restaurant {
    // ID del restaraurante
    private int restId;

    // El Nombre del restaurante
    private String restTitle;

    // Una pequeñas descripcion del restaurante
    private String restDesc;

    // Un enlace html que redirige a la Firebase Storage
    private String restImg;

    public Restaurant(){

    }

    public Restaurant(int restId, String restTitle, String restDesc, String restImg) {
        this.restId = restId;
        this.restTitle = restTitle;
        this.restDesc = restDesc;
        this.restImg = restImg;
    }

    public int getRestId() {
        return restId;
    }

    public String getRestTitle() {
        return restTitle;
    }

    public String getRestDesc() {
        return restDesc;
    }

    public String getRestImg() {
        return restImg;
    }
}
